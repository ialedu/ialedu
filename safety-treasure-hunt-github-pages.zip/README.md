# Safety Treasure Hunt – Gamification Sicurezza sul Lavoro

Questo progetto contiene un quiz interattivo gamificato in HTML/JS, pronto per l'hosting su **GitHub Pages**.

## Istruzioni

1. Carica questi file in un repository GitHub.
2. Vai in `Settings > Pages` e abilita GitHub Pages dalla root del branch.
3. L'app sarà disponibile su: `https://<tuo-username>.github.io/<repo-name>/`
4. Può essere integrata in Articulate Rise tramite blocco "Embed".

✔️ Completamente client-side  
📱 Responsive  
🛡️ Adatto a corsi sulla sicurezza aziendale
